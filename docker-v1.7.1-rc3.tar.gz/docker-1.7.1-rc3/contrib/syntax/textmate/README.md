# Docker.tmbundle

Dockerfile syntaxt highlighting for TextMate and Sublime Text.

## Install

### Sublime Text

Available for Sublime Text under [package control](https://sublime.wbond.net/packages/Dockerfile%20Syntax%20Highlighting).
Search for *Dockerfile Syntax Highlighting*

### TextMate 2

Copy the directory `Docker.tmbundle` (showed as a Package in OSX) to `~/Library/Application Support/TextMate/Managed/Bundles`

enjoy.
