This directory contains code pertaining to running containers and storing images

Code pertaining to running containers:

 - execdriver
 - networkdriver

Code pertaining to storing images:

 - graphdriver
