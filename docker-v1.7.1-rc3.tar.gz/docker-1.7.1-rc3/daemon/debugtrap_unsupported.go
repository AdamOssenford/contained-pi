// +build !linux,!darwin,!freebsd

package daemon

func setupSigusr1Trap() {
	return
}
