// +build !linux

package zfs
