// +build daemon

package main

const (
	// tests can assume daemon runs on the same machine as CLI
	isLocalDaemon = true
)
