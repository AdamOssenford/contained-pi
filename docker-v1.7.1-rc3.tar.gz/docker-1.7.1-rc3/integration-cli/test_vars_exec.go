// +build !test_no_exec

package main

const (
	// indicates docker daemon tested supports 'docker exec'
	supportsExec = true
)
